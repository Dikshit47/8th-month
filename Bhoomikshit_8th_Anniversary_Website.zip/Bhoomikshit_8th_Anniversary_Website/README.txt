Bhoomikshit - 8th Month Anniversary Website

Project structure:
- index.html
- style.css
- script.js
- assets/
   - photo1.jpg
   - photo2.jpg
   - photo3.jpg
   - music.mp3

This is a starter project package. Replace the asset placeholders with your own files.
